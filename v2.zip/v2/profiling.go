package main

import (
	"log"
	"runtime"
	"sync/atomic"
	"time"
)

// ProfileStats rastreia estatísticas de performance
type ProfileStats struct {
	// FFmpeg
	ffmpegReadTime   atomic.Int64 // nanoseconds
	ffmpegReadCount  atomic.Uint64

	// Frame processing
	frameDecodeTime  atomic.Int64
	frameDecodeCount atomic.Uint64

	// Publishing
	publishTime      atomic.Int64
	publishCount     atomic.Uint64

	// Memory
	lastGCPause      atomic.Uint64 // microseconds
	gcCount          atomic.Uint32

	// Goroutines
	goroutineCount   atomic.Int32
}

var globalProfile ProfileStats

// TrackFFmpegRead rastreia tempo de leitura do FFmpeg
func TrackFFmpegRead(duration time.Duration) {
	globalProfile.ffmpegReadTime.Add(int64(duration))
	globalProfile.ffmpegReadCount.Add(1)
}

// TrackFrameDecode rastreia tempo de decode
func TrackFrameDecode(duration time.Duration) {
	globalProfile.frameDecodeTime.Add(int64(duration))
	globalProfile.frameDecodeCount.Add(1)
}

// TrackPublish rastreia tempo de publicação
func TrackPublish(duration time.Duration) {
	globalProfile.publishTime.Add(int64(duration))
	globalProfile.publishCount.Add(1)
}

// UpdateMemoryStats atualiza stats de memória
func UpdateMemoryStats() {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	globalProfile.lastGCPause.Store(m.PauseNs[(m.NumGC+255)%256] / 1000) // Convert to microseconds
	globalProfile.gcCount.Store(m.NumGC)
	globalProfile.goroutineCount.Store(int32(runtime.NumGoroutine()))
}

// PrintProfileReport imprime relatório de profiling
func PrintProfileReport() {
	sep := "================================================================"
	log.Println("\n" + sep)
	log.Println("                  PERFORMANCE PROFILE")
	log.Println(sep)

	// FFmpeg stats
	ffmpegReads := globalProfile.ffmpegReadCount.Load()
	if ffmpegReads > 0 {
		avgFFmpeg := time.Duration(globalProfile.ffmpegReadTime.Load() / int64(ffmpegReads))
		log.Printf("🎥 FFmpeg Read:")
		log.Printf("   Avg Time:  %v", avgFFmpeg)
		log.Printf("   Count:     %d", ffmpegReads)
	}

	// Decode stats
	decodes := globalProfile.frameDecodeCount.Load()
	if decodes > 0 {
		avgDecode := time.Duration(globalProfile.frameDecodeTime.Load() / int64(decodes))
		log.Printf("🔧 Frame Decode:")
		log.Printf("   Avg Time:  %v", avgDecode)
		log.Printf("   Count:     %d", decodes)
	}

	// Publish stats
	publishes := globalProfile.publishCount.Load()
	if publishes > 0 {
		avgPublish := time.Duration(globalProfile.publishTime.Load() / int64(publishes))
		log.Printf("📤 Publishing:")
		log.Printf("   Avg Time:  %v", avgPublish)
		log.Printf("   Count:     %d", publishes)
		log.Printf("   ⚠️  GARGALO DETECTADO: Latência de %v é MUITO alta!", avgPublish)
	}

	// Memory stats
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	log.Printf("💾 Memory:")
	log.Printf("   Alloc:     %.2f MB", float64(m.Alloc)/(1024*1024))
	log.Printf("   Sys:       %.2f MB", float64(m.Sys)/(1024*1024))
	log.Printf("   GC Count:  %d", m.NumGC)
	log.Printf("   Last GC:   %v µs", globalProfile.lastGCPause.Load())

	log.Printf("🔀 Goroutines: %d", runtime.NumGoroutine())

	log.Println(sep + "\n")
}

// StartProfileMonitor inicia monitor de profiling
func StartProfileMonitor() {
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()

		for range ticker.C {
			UpdateMemoryStats()
		}
	}()
}
